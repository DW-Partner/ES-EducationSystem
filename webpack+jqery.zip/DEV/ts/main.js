
// import './main.css';//使用require导入css文件
// import $ from 'jQuery';
//require('./main.css');

//import './main.css';//使用require导入css文件

require('./main2.scss');



console.log($);
console.log(454655);
$('#root').css({
	border:"1px solid #ddd",
	background:"#999"
})