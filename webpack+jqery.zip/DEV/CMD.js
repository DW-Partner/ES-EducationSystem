(function(context) {


	// const $$ = context.$ = require('./jquery.min.js');
	context.$ = require('jquery');


	$('body').css({
		background: '#ccc'
	})



	let stopDefault = (e) => {
		if (e && e.preventDefault) {
			e.preventDefault();

		} else {
			window.event.returnValue = false;
		}

	}


	let ajaxGetHtml = (url) => {
		$.ajax({
			type: "get",
			dataType: "html",
			url: url,
			data: {},
			success: (html)=>{
				if( html === 'xxxx' ){
					window.location.href = 'xxxx';
					return;
				}

				//distory()


			},
			error: ()=>{

			}
		})
	}



	$(document).on('click', '#left_nav a', (e)=>{
		stopDefault(e);
		const url = $(this).attr('href');


	})


})(window)